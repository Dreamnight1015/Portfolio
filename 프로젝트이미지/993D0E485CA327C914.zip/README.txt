A Pen created at CodePen.io. You can find this one at https://codepen.io/tedmcdo/pen/PqxKXg.

 I wanted to animated waves for the background of a page. Initially I tried a staggered loop animation in Javascript, but some mobile devices struggled really bad. This CSS3 version is hardware accelerated, simple, and is much more performant.